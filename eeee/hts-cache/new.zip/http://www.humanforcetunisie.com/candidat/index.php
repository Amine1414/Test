<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>HUMAN FORCE TUNISIE: Intérim et offre d'emploi </title>
<meta name="Keywords" content="interim, travail temporaire, recrutement, tunisie, interim tunisie, recrutement tunisie, offre emploie, demande emploi, offre travail, contrat travail, human force, audit social, conseil, outsourcing tunisie, externalisation tunisie, portage salarial, cv, job, travail, agence interim, cdi, cdd, assistante, secretaire, technicien" >
<meta name="Description" content="HUMAN FORCE, consultez les offres d'emploi en Tunisie et à l'étranger. Déposez votre candidature directement en ligne ." >
<meta name="language" content="fr">
<META NAME="SUBJECT" CONTENT="Intérim, Travail temporaire, Recrutement, Gestion de contrat, Outsourcing, Audit social, portage salarial">
<meta name="robots" content="index, follow">
<meta name="author" content="HUMAN FORCE">
<META NAME="OWNER" CONTENT="contact@humanforcetunisie.com">
<META NAME="RATING" CONTENT="emploi">
<meta name=identifier-url content="http://www.humanforcetunisie.com">
<meta name="copyright" content="HUMAN FORCE &copy; 2007">

<meta name="category" content="emploi">
<LINK REL="SHORTCUT ICON" HREF="../images/logo.ico">
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2585467-1");
pageTracker._initData();
pageTracker._trackPageview();
</script>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<link href="../style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.Style2 {color: #910412}
.Style3 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
}
-->
</style>
</head>

<body bgcolor="#FFFFFF" style="background-image: url(../images/b.gif); background-repeat: repeat-y; background-position: right;" onLoad="MM_preloadImages('../images/ar2.gif')" >
	<table width="100%"  style="height:800px" border="0" cellspacing="0" cellpadding="0" align="center">
	  	  	  <tr>
		<td width="100%" style="height:100px" valign="top">
			<table width="100%" style="background-image: url(/images/t-dr.jpg); background-repeat: repeat-x; height:100px" border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td width="673" style="background-image: url(/images/t-l.gif); background-repeat: repeat-x; height:100px" valign="top">
					<table width="673" style="height:100px" border="0" cellspacing="0" cellpadding="0">
					  <tr>
						<td width="186" style="height:100px" valign="top">
							<div style="margin-left:45px; margin-top:20px; height:18px;margin-bottom:2px;"><a onClick="this.style.behavior='url(#default#homepage)';this.setHomePage('http://www.humanforcetunisie.com');return false;" href="#"><img alt="Rendre HUMAN FORCE votre page par d�fault" border="0" src="/images/pagedef.gif"></a> 
						<a  href="/recommander-ami.php"><img style="margin-left:20px;" alt="Recommander HUMAN FORCE � un ami" border="0" src="/images/recomamis.gif"></a>
						<a onClick="window.external.AddFavorite('http://www.humanforcetunisie.com', 'HUMAN FORCE - int�rim et rerutement');return(false);" href="#"><img style="margin-left:20px;" alt="Ajouter HUMAN FORCE aux Favoris" border="0" src="/images/favoris.gif"></a>
						<!--<a href="index.php"><img style="margin-left:20px;" alt="Afficher le plan du site HUMAN FORCE" border="0" src="images/plansit.gif"></a>//--></div> 
							<div style="margin-left:2px" ><a href="/index.php"><img alt="Bienvenue � votre Agence HUMAN FORCE, Partenaire du Capital Humain" border="0" src="/images/logo1.gif"></a></div>
							<div style="margin-left:75px; margin-top:10px;"><img alt="" border="0" src="/images/logo2.gif"></div>
						</td>
						<td width="487" style="height:100px" valign="top">
							<div style="margin-left:0px; margin-top:10px"><a href="/index.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('r1','','/images/l1-1.gif',1)"><img alt="" src="/images/l1.gif" name="r1" border="0"></a><a href="/nos-valeurs.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('r2','','/images/l2-2.gif',1)"><img src="/images/l2.gif" alt="" name="r2" width="120" height="57" border="0"></a><a href="/interim-recrutement.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('r3','','/images/l3-3.gif',1)"><img alt="" src="/images/l3.gif" name="r3" border="0"></a><a href="/contact-consultation-gratuite.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('r4','','/images/l4-4.gif',1)"><img  alt="" src="/images/l4.gif" name="r4" border="0"></a></div>
							<div style="margin-left:0px; margin-top:11px;"><img alt="" border="0" src="/images/logo3.gif"></div>
						</td>
					  </tr>
					</table>
				</td>
				<td width="100%" style="background-image: url(/images/t-r.gif); background-repeat: no-repeat; background-position: right;height:100px" valign="top"><div><img  src="/images/spacer.gif" alt="" width="93" height="1"  border="0"></div></td>
			  </tr>
			</table>
		</td>
	  </tr>	   <tr>
		<td width="100%" style="height:236px" valign="top">
			<table width="100%" style="background-image: url(/images/f-dr.gif); background-repeat: repeat-x; height:236px" border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td width="330" style="background-image: url(/images/f.jpg); background-repeat: no-repeat; height:236px" valign="top">
					<div style="margin-left:39px; margin-top:82px; margin-right:82px">
                     <map name="FPMap0">
                        <area coords="1,91,204,115" shape="rect" href="/interim-recrutement.php">
                        <area coords="1, 61, 204, 85" shape="rect" href="/interim-recrutement.php">
                        <area coords="1,31,204,58" shape="rect" href="/entreprise/recrutement-tunisie.php">
                        <area coords="1,1,204,27" shape="rect" href="/entreprise/interim-tunisie.php">
                    </map>
    <img alt="" border="0" usemap="#FPMap0" src="/images/slogan.gif"></div>
				</td>
				<td width="100%" style="background-image: url(/images/men.jpg); background-repeat: no-repeat; background-position: right;height:236px" valign="top"></td>
			  </tr>
			</table>
		</td>
	  </tr>	  <tr>
		<td width="100%" style="height:464px" valign="top">
			<table width="100%" style="height:464px" border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td width="100%" style="height:464px" valign="top">
					<table width="100%" style="height:464px" border="0" cellspacing="0" cellpadding="0">
					  <tr>
						<td width="100%" style="height:425px" valign="top">
							<table width="100%" style="height:425px" border="0" cellspacing="0" cellpadding="0">
							  <tr>
								<td width="37%" style="height:100%" valign="top">
									<table width="100%" style="height:100%" border="0" cellspacing="0" cellpadding="0">
									  <tr>
										<td class="m_text" width="100%" style="height:100%" bgcolor="#F3F3F3" valign="top">
											<TABLE>
<tr>
<td style=" background-image:url(/images/BordureMenu.gif); background-repeat:no-repeat;background-position:top left;  height:100px;margin-bottom:15px;margin-right:10px">
<div style="margin-left:21px; margin-top:31px; margin-right:40px; margin-bottom:20px">
										
											
												<div align="left" style="margin-left:px; margin-top:20px;"><a href="/candidat/index.php"><img  alt="Recrutement en Tunisie - Espace Candidat" border="0" src="/images/can.gif"></a></div>
											<div style="margin-left:px; margin-top:10px; margin-right:px; margin-bottom:px">
											
													<div align="left" class="_text" style="margin-left:px; margin-top:3px; margin-right:px">
													  <div style="margin-top:10px"><a href="/index-7.php" class="l_text">D&eacute;posez votre candidature</a></div>
													  <div style="margin-top:10px"><a href="/candidat/offre-emploi-human-force.php" class="l_text">Consulter les offres d'emploi</a></div>
													   <div style="margin-top:10px"><a href="/candidat/interimaire-human-force.php" class="l_text">Int&eacute;rimaire chez HUMAN FORCE</a></div>
													   <div style="margin-top:10px"><a href="/candidat/rediger-cv.php" class="l_text">R&eacute;ussir son CV</a></div>
													 
													   <div style="margin-top:10px"><a href="/candidat/Simulation-fiche-de-paie.php" class="l_text">Simulation Salaire Net </a></div>
													  
													</div>
  </div>
</div>
</td>
</tr>
<tr>
<td style=" background-image:url(/images/BordureMenu.gif); background-repeat:no-repeat;background-position:top left;  height:100px;margin-bottom:15px;margin-right:10px">

<div align="left" class="_text" style="margin-left:21px; margin-top:3px; margin-right:px">
<div style="margin-left:px; margin-top:31px; margin-right:40px; margin-bottom:20px"><a href="/entreprise/index.php"><img src="/images/et.gif"  alt="Recrutement en Tunisie - Espace Entreprise"  border="0"></a></div>


													<div  style="margin-top:2px"><a href="/entreprise/espace-entreprise.php" class="l1_text">Espace Client </a></div>
													  <div style="margin-top:10px"><a href="/entreprise/offre-emploi.php" class="l1_text">D&eacute;posez une offre d'emploi </a></div>
													  <div  style="margin-top:10px"><a href="/entreprise/interim-tunisie.php" class="l1_text">Int&eacute;rim en Tunisie</a></div>
													  <div  style="margin-top:10px"><a href="/entreprise/recrutement-tunisie.php" class="l1_text">Recrutement en Tunisie </a></div>
													  
													  <div  style="margin-top:10px"><a href="/entreprise/portage-salarial-tunisie.php" class="l1_text">Portage salarial </a></div>
													  <div  style="margin-top:10px"><a href="/Bibli/index.php" class="l1_text">Bibioth&egrave;que Human Force &quot;Droit social&quot; </a></div>
													  
													</div></div>
</td>
</tr>
</table>										</td>
									  </tr>
									  <tr>
										<td width="100%" style="height:59px" bgcolor="#0C7440" valign="top">
											<div align="left" class="c_text" style="margin-left:29px; margin-top:22px; margin-right:px"><span class="c_text" style="margin-left:0px; margin-top:24px; margin-right:px">HUMAN FORCE &copy; 2017</span>&nbsp; |&nbsp; <a href="/terme-utilisation.php" class="c_text">Termes d'Utilisation  &nbsp; </a> 
</div>										</td>
									  </tr>
								  </table>
								</td>
								<td width="6" style="height:425px" valign="top"><div><img  src="../images/spacer.gif" alt="" width="6" height="1"  border="0"></div></td>
								<td width="63%" height="100" valign="top" style="height:100%">
									<table width="100%" style="height:100%" border="0" cellspacing="0" cellpadding="0">
									  <tr>
										<td width="100%" style="height:100%" valign="top">
											<table width="100%" style="height:100%" border="0" cellspacing="0" cellpadding="0">
											  <tr>
												<td width="100%"   valign="top">
													<div class="Style1" style="margin-left:15px; margin-top:31px;">ESPACE <span class="Style2">CANDIDAT</span> </div>
													<div style="margin-left:13px; margin-top:14px; margin-right:20px; margin-bottom:10px">
														<div>
														<table width="460" border="0" cellspacing="0" cellpadding="0">
  <tr>
<td width="230px"  valign="top">
<div style=" background-image:url(/images/bordurehautcandi.gif); background-repeat:no-repeat;background-position:top left;  height:100px;margin-bottom:15px;margin-right:10px">

	<div style="margin-bottom:10px; margin-left:10px"><BR><img src="/images/fleche.gif" width="15" height="15" hspace="3" vspace="0" ><a href="/index-7.php" class="Style2 Style3"><strong>Déposez votre CV	</strong></a>	</div>
	
	<div class="m_text" style="margin-bottom:0px; margin-left:10px">
	  <div align="justify">Vous souhaitez être contacté lorsqu'un poste correspondant à vos compétences sera à pourvoir. <a href="/index-7.php" class="l1_text">Déposez votre candidature</a> directement en ligne. <BR>
	    &nbsp;	</div>
	</div>
	</div>
	</td>
    <td width="230px" valign="top">
	<div style=" background-image:url(/images/bordurehautcandi.gif); background-repeat:no-repeat;background-position:top left; height:100px;margin-bottom:15px;">
	<div style="margin-bottom:10px; margin-left:10px"><BR><img src="/images/fleche.gif" width="15" height="15" hspace="3" vspace="0" ><a href="/candidat/offre-emploi-human-force.php" class="Style2 Style3"><strong>Les offres d'emploi	</strong></a>	</div>
	<div class="m_text" style="margin-bottom:15px; margin-left:10px">
	  <div align="justify">Vous êtes à la rechcerche d'un poste qui correspond mieux à votre qualification. Consultez nos <a href="/candidat/offre-emploi-human-force.php" class="l1_text">offres d'emploi</a> en ligne.<BR>
	    &nbsp;</div>
	</div></div>
	</td>
  </tr>
  <tr>
    <td width="230px" valign="top">
	<div style=" background-image:url(/images/bordurehautcandi.gif); background-repeat:no-repeat;background-position:top left;  height:100px;margin-bottom:15px;margin-right:10px">

	<div style="margin-bottom:10px; margin-left:10px"><BR><img src="/images/fleche.gif" width="15" height="15" hspace="3" vspace="0" ><a href="/candidat/rediger-cv.php" class="Style2 Style3"><strong>Rédaction d'un CV </strong></a>	</div>
	<div class="m_text" style="margin-bottom:15px; margin-left:10px">
	  <div align="justify">Pour vous aider à bien rédiger votre CV et optimiser vos chances de décrocher un emploi <a href="/candidat/rediger-cv.php" class="l1_text">consultez nos conseils</a>. <BR>
	    &nbsp;</div>
	</div></div>
	</td>
    <td width="230px" valign="top">
	<div style=" background-image:url(/images/bordurehautcandi.gif); background-repeat:no-repeat;background-position:top left;  height:100px;margin-bottom:15px;">

	<div style="margin-bottom:10px; margin-left:10px"><BR><img src="/images/fleche.gif" width="15" height="15" hspace="3" vspace="0" ><a href="/candidat/interimaire-human-force.php" class="Style2 Style3"><strong>Intérimaire chez HF </strong></a>	</div>
	<div class="m_text" style="margin-bottom:15px; margin-left:10px">
	  <div align="justify">Vous voulez en savoir plus sur l'intérim et les droits et obligations de l'intérimaire chez <strong>HUMAN FORCE. </strong> Découvrez notre <span class="l1_text"><a href="/candidat/interimaire-human-force.php" class="l1_text">espace intérimaire</a>.</span><BR>
	    &nbsp;</div>
	</div></div>
	</td>
  </tr>
  </table>

<table width="460" border="0" cellspacing="0" cellpadding="0">

<tr>    
    <td width="460px" valign="top">
	<div style=" background-image:url(/images/bordurehautcandi.gif); background-repeat:no-repeat;background-position:top left; height:100px;margin-bottom:15px;">

	<div style="margin-bottom:10px; margin-left:10px"><BR><img src="/images/fleche.gif" width="15" height="15" hspace="3" vspace="0" ><a href="/candidat/Simulation-fiche-de-paie.php" class="Style2 Style3"><strong>Fiche de paie </strong></a>	</div>
	<div class="m_text" style="margin-bottom:15px; margin-left:10px">
	  <div align="justify">Votre employeur vous propose un salaire Brut et vous voulez avoir une idée sur le salaire net. <a href="/candidat/Simulation-fiche-de-paie.php" class="l1_text">Suivez le simulateur</a>. <BR>
	    &nbsp;</div>
	</div></div>
	</td>
  </tr>
</table>

<table width="460" border="0" cellspacing="0" cellpadding="0">

<tr>
    <td width="460px" height="130px" valign="top">
	<div style=" background-image:url(/images/bordurehautcandi.gif); background-repeat:no-repeat;background-position:top left; height:100px">

	<div style="margin-bottom:10px; margin-left:10px"><BR><img src="/images/fleche.gif" width="15" height="15" hspace="3" vspace="0" ><a href="/entreprise/portage-salarial-tunisie.php" class="Style2 Style3"><strong>Portage salarial  </strong></a>	</div>
	<div class="m_text" style="margin-bottom:15px; margin-left:10px">
	  <div align="justify">Vous êtes un cadre en activité ou en recherche d'emploi, un jeune diplômé, un créateur souhaitant tester un projet professionnel, un demandeur d'emploi cherchant à proposer ses compétences. Votre donneur d'ordre ne souhaite pas vous embaucher pour la réalisation de ces missions et vous ne souhaitez pas dans un premier temps créer votre propre entreprise... <br>
	    Alors le <a href="/entreprise/portage-salarial-tunisie.php" class="l1_text">portage salarial</a> est la solution pour vous permettre de réaliser vos missions ou pour tester un projet.</div>
	</div></div>
	</td>

  </tr>
</table>
</div>
														
											    </div></td>
											  </tr>
											  <tr>
												<td width="100%" style="height:1px" bgcolor="#DADADA" valign="top"></td>
											  </tr>
											  <tr>
												<td width="100%" valign="top" style="height:100%">
													
													
														
												  <div style="margin-left:13px; margin-top:35px; margin-right:26px; margin-bottom:20px">
														<div><img alt="Assistance juridique - Conseil en Ressources Humaines" src="../images/1-p3-5.jpg" hspace="0" vspace="0" border="0" align="left" style="margin-right:20px; margin-top:0px"></div>
														
														<div align="left" class="l_text" style="margin-top:2px"><strong class="l_text"><u>Qui contacter? </u><a name="Ind1_5"></a></strong></div>
														<div align="left" class="m_text" style="margin-left:px; margin-top:4px; margin-right:px">
														  <div align="justify">Un interlocuteur unique vous sera affecté pour toute demande d'information ou réclamation. <br>
														  
														    <br>
<table width="340" style="height:px" border="0" cellspacing="0" cellpadding="0">
														  <tr>
															<td colspan="2" valign="top" class="m_text" style="height:px">
																<img alt="" border="0" src="../images/logo1.gif">
																<div><img  src="/images/spacer.gif" alt="" width="1" height="4"  border="0"></div>
																<div style="margin-left:75px; margin-bottom:15px;"><img alt="HUMAN FORCE, Partenaire du Capital Humain" border="0" src="../images/logo2.gif"><img alt="" border="0" src="../images/logo3.gif"></div>
<a href="/contact-consultation-gratuite.php" class="l1_text"><strong>Nous contacter...</strong></a>
<div><img  src="/images/spacer.gif" alt="" width="1" height="4"  border="0"></div></td>
														  </tr>
  														  <tr>
														    <td width="61" valign="top" class="m_text" style="height:px"><span class="m_text" style="height:px">
Email: </span></td>
													        <td width="279" valign="top" class="m_text" style="height:px">
															<a href="mailto:recrutement@humanforcetunisie.com" class="l1_text">recrutement@humanforcetunisie.com</a></td>
														  </tr>
														   <tr>
                                                        <td colspan="2" valign="top" class="m_text" style="height:px"><div><img  src="/images/spacer.gif" alt="" width="1" height="15"  border="0"></div>
                                                            <strong><a href="/plan-acces.php" class="l1_text">Plan d'accés - HUMAN FORCE</a></strong><br>
                                                            <div><img  src="/images/spacer.gif" alt="" width="1" height="4"  border="0"></div></td>
                                                      </tr>
													  </table>
														  </div>
														</div>
													    <div align="right" class="l1_text" style=" margin-top:30px; margin-right:px"><a href="/candidat/index.php" target="_top" class="l1_text" onMouseOver="MM_swapImage('ar','','../images/ar2.gif',1)" onMouseOut="MM_swapImgRestore()"> <img src="../images/ar3.gif" alt="Revenir en haut de la page"  border = "0" name="ar"style="margin-right:3px" >haut de la page</a></div>
										        </div>								</td>
											  </tr>
										  </table>
										</td>
									  </tr>
									  <tr>
										<td width="100%" style="background-image: url(../images/b-dr.gif); background-repeat: repeat-x; height:59px" valign="top">
											<div style="margin-left:17px; margin-top:20px; margin-right:px; margin-bottom:px">
											<form id="form1" action="interimaire-human-force.php" enctype="multipart/form-data" name="form1" style="margin:0px; padding:0px">
												<table width="366" style="height:px" border="0" cellspacing="0" cellpadding="0">
												  <tr>
													<td width="184" style="height:px" valign="top"><div style="margin-left:px; margin-top:px;"><img alt="" border="0" src="../images/t4.gif"></div></td>
													<td width="141" style="height:px" valign="top"><input type="text" class="form1 m_text" value="Entrer votre email" style="color:#6A6A6A"></td>
													<td width="41" style="height:px" valign="top"><input type="image" src="../images/ok.gif"></td>
												  </tr>
												</table>
											</form>
											</div>
										</td>
									  </tr>
									</table>
								</td>
								<td width="7" style="height:425px" valign="top"><div><img  src="../images/spacer.gif" alt="" width="7" height="1"  border="0"></div></td>
							  </tr>
						  </table>
						</td>
					  </tr>
					  <tr>
						<td width="100%" style="height:39px" valign="top"></td>
					  </tr>
					</table>
				</td>
				<td width="48" style=" height:464px" valign="top" ><div style="margin-left:px; margin-top:px;"><img alt="" border="0" src="../images/r.gif"></div></td>
			  </tr>
			</table>
		</td>
	  </tr>
	</table>
</body>
</html>