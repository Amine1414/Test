<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>HUMAN FORCE TUNISIE: offre d'emploi et travail en Tunisie</title>
<meta name="Keywords" content="interim, travail temporaire, recrutement, tunisie, interim tunisie, recrutement tunisie, offre emploie, demande emploi, offre travail, contrat travail, human force, audit social, conseil, outsourcing tunisie, externalisation tunisie, portage salarial, cv, job, travail, agence interim, cdi, cdd, assistante, secretaire, technicien" >
<meta name="Description" content="HUMAN FORCE, Consultez les offres d'emploi du cabinet de recrutement et d'intérim HUMAN FORCE Tunisie. Augmentez vos chances pour trouver un travail en Tunisie." >
<meta name="language" content="fr">
<META NAME="SUBJECT" CONTENT="Intérim, Travail temporaire, Recrutement, Gestion de contrat, Outsourcing, Audit social, portage salarial">
<meta name="robots" content="index, follow">
<meta name="author" content="HUMAN FORCE">
<META NAME="OWNER" CONTENT="contact@humanforcetunisie.com">
<META NAME="RATING" CONTENT="emploi">
<meta name=identifier-url content="http://www.humanforcetunisie.com">
<meta name="copyright" content="HUMAN FORCE &copy; 2007">

<meta name="category" content="emploi">
<LINK REL="SHORTCUT ICON" HREF="../images/logo.ico">
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2585467-1");
pageTracker._initData();
pageTracker._trackPageview();
</script>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<link href="../style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.Style2 {color: #910412}
.Style4 {
	font-size: 18px;
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
	line-height: 17px;
}
.Style5 {font-size: 14px}
-->
</style>
</head>

<body bgcolor="#FFFFFF" style="background-image: url(../images/b.gif); background-repeat: repeat-y; background-position: right;" onLoad="MM_preloadImages('../images/ar2.gif')" >
<table width="100%"  style="height:800px" border="0" cellspacing="0" cellpadding="0" align="center">
	  	  	  <tr>
		<td width="100%" style="height:100px" valign="top">
			<table width="100%" style="background-image: url(/images/t-dr.jpg); background-repeat: repeat-x; height:100px" border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td width="673" style="background-image: url(/images/t-l.gif); background-repeat: repeat-x; height:100px" valign="top">
					<table width="673" style="height:100px" border="0" cellspacing="0" cellpadding="0">
					  <tr>
						<td width="186" style="height:100px" valign="top">
							<div style="margin-left:45px; margin-top:20px; height:18px;margin-bottom:2px;"><a onClick="this.style.behavior='url(#default#homepage)';this.setHomePage('http://www.humanforcetunisie.com');return false;" href="#"><img alt="Rendre HUMAN FORCE votre page par d�fault" border="0" src="/images/pagedef.gif"></a> 
						<a  href="/recommander-ami.php"><img style="margin-left:20px;" alt="Recommander HUMAN FORCE � un ami" border="0" src="/images/recomamis.gif"></a>
						<a onClick="window.external.AddFavorite('http://www.humanforcetunisie.com', 'HUMAN FORCE - int�rim et rerutement');return(false);" href="#"><img style="margin-left:20px;" alt="Ajouter HUMAN FORCE aux Favoris" border="0" src="/images/favoris.gif"></a>
						<!--<a href="index.php"><img style="margin-left:20px;" alt="Afficher le plan du site HUMAN FORCE" border="0" src="images/plansit.gif"></a>//--></div> 
							<div style="margin-left:2px" ><a href="/index.php"><img alt="Bienvenue � votre Agence HUMAN FORCE, Partenaire du Capital Humain" border="0" src="/images/logo1.gif"></a></div>
							<div style="margin-left:75px; margin-top:10px;"><img alt="" border="0" src="/images/logo2.gif"></div>
						</td>
						<td width="487" style="height:100px" valign="top">
							<div style="margin-left:0px; margin-top:10px"><a href="/index.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('r1','','/images/l1-1.gif',1)"><img alt="" src="/images/l1.gif" name="r1" border="0"></a><a href="/nos-valeurs.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('r2','','/images/l2-2.gif',1)"><img src="/images/l2.gif" alt="" name="r2" width="120" height="57" border="0"></a><a href="/interim-recrutement.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('r3','','/images/l3-3.gif',1)"><img alt="" src="/images/l3.gif" name="r3" border="0"></a><a href="/contact-consultation-gratuite.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('r4','','/images/l4-4.gif',1)"><img  alt="" src="/images/l4.gif" name="r4" border="0"></a></div>
							<div style="margin-left:0px; margin-top:11px;"><img alt="" border="0" src="/images/logo3.gif"></div>
						</td>
					  </tr>
					</table>
				</td>
				<td width="100%" style="background-image: url(/images/t-r.gif); background-repeat: no-repeat; background-position: right;height:100px" valign="top"><div><img  src="/images/spacer.gif" alt="" width="93" height="1"  border="0"></div></td>
			  </tr>
			</table>
		</td>
	  </tr>	   <tr>
		<td width="100%" style="height:236px" valign="top">
			<table width="100%" style="background-image: url(/images/f-dr.gif); background-repeat: repeat-x; height:236px" border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td width="330" style="background-image: url(/images/f.jpg); background-repeat: no-repeat; height:236px" valign="top">
					<div style="margin-left:39px; margin-top:82px; margin-right:82px">
                     <map name="FPMap0">
                        <area coords="1,91,204,115" shape="rect" href="/interim-recrutement.php">
                        <area coords="1, 61, 204, 85" shape="rect" href="/interim-recrutement.php">
                        <area coords="1,31,204,58" shape="rect" href="/entreprise/recrutement-tunisie.php">
                        <area coords="1,1,204,27" shape="rect" href="/entreprise/interim-tunisie.php">
                    </map>
    <img alt="" border="0" usemap="#FPMap0" src="/images/slogan.gif"></div>
				</td>
				<td width="100%" style="background-image: url(/images/men.jpg); background-repeat: no-repeat; background-position: right;height:236px" valign="top"></td>
			  </tr>
			</table>
		</td>
	  </tr>	  <tr>
		<td width="100%" style="height:464px" valign="top">
		  <table width="100%" style="height:464px" border="0" cellspacing="0" cellpadding="0">
  <tr>
  
  <td width="100%" style="height:464px" valign="top">
  
  <table width="100%" style="height:464px" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%" style="height:425px" valign="top">
      <table width="100%" style="height:425px" border="0" cellspacing="0" cellpadding="0">
        <tr>
        
        <td width="37%" style="height:100%" valign="top"><table width="100%" style="height:100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td class="m_text" width="100%" style="height:100%" bgcolor="#F3F3F3" valign="top"><TABLE>
<tr>
<td style=" background-image:url(/images/BordureMenu.gif); background-repeat:no-repeat;background-position:top left;  height:100px;margin-bottom:15px;margin-right:10px">
<div style="margin-left:21px; margin-top:31px; margin-right:40px; margin-bottom:20px">
										
											
												<div align="left" style="margin-left:px; margin-top:20px;"><a href="/candidat/index.php"><img  alt="Recrutement en Tunisie - Espace Candidat" border="0" src="/images/can.gif"></a></div>
											<div style="margin-left:px; margin-top:10px; margin-right:px; margin-bottom:px">
											
													<div align="left" class="_text" style="margin-left:px; margin-top:3px; margin-right:px">
													  <div style="margin-top:10px"><a href="/index-7.php" class="l_text">D&eacute;posez votre candidature</a></div>
													  <div style="margin-top:10px"><a href="/candidat/offre-emploi-human-force.php" class="l_text">Consulter les offres d'emploi</a></div>
													   <div style="margin-top:10px"><a href="/candidat/interimaire-human-force.php" class="l_text">Int&eacute;rimaire chez HUMAN FORCE</a></div>
													   <div style="margin-top:10px"><a href="/candidat/rediger-cv.php" class="l_text">R&eacute;ussir son CV</a></div>
													 
													   <div style="margin-top:10px"><a href="/candidat/Simulation-fiche-de-paie.php" class="l_text">Simulation Salaire Net </a></div>
													  
													</div>
  </div>
</div>
</td>
</tr>
<tr>
<td style=" background-image:url(/images/BordureMenu.gif); background-repeat:no-repeat;background-position:top left;  height:100px;margin-bottom:15px;margin-right:10px">

<div align="left" class="_text" style="margin-left:21px; margin-top:3px; margin-right:px">
<div style="margin-left:px; margin-top:31px; margin-right:40px; margin-bottom:20px"><a href="/entreprise/index.php"><img src="/images/et.gif"  alt="Recrutement en Tunisie - Espace Entreprise"  border="0"></a></div>


													<div  style="margin-top:2px"><a href="/entreprise/espace-entreprise.php" class="l1_text">Espace Client </a></div>
													  <div style="margin-top:10px"><a href="/entreprise/offre-emploi.php" class="l1_text">D&eacute;posez une offre d'emploi </a></div>
													  <div  style="margin-top:10px"><a href="/entreprise/interim-tunisie.php" class="l1_text">Int&eacute;rim en Tunisie</a></div>
													  <div  style="margin-top:10px"><a href="/entreprise/recrutement-tunisie.php" class="l1_text">Recrutement en Tunisie </a></div>
													  
													  <div  style="margin-top:10px"><a href="/entreprise/portage-salarial-tunisie.php" class="l1_text">Portage salarial </a></div>
													  <div  style="margin-top:10px"><a href="/Bibli/index.php" class="l1_text">Bibioth&egrave;que Human Force &quot;Droit social&quot; </a></div>
													  
													</div></div>
</td>
</tr>
</table>            </td>
          </tr>
          <tr>
            <td width="100%" style="height:59px" bgcolor="#0C7440" valign="top"><div align="left" class="c_text" style="margin-left:29px; margin-top:22px; margin-right:px"><span class="c_text" style="margin-left:0px; margin-top:24px; margin-right:px">HUMAN FORCE &copy; 2017</span>&nbsp; |&nbsp; <a href="/terme-utilisation.php" class="c_text">Termes d'Utilisation  &nbsp; </a> 
</div></td>
          </tr>
        </table></td>
        <td width="6" style="height:425px" valign="top"><div><img  src="../images/spacer.gif" alt="" width="6" height="1"  border="0"></div></td>
        <td width="63%" style="height:100%" valign="top">
        
        <table width="100%" style="height:100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
          
          <td width="100%" style="height:100%" valign="top">
          
          <table width="100%" style="height:100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" style="height:40px" valign="top"><div class="Style1" style="margin-left:15px; margin-top:31px;">OFFRE EMPLOI  <span class="Style2">HUMAN FORCE</span> </div></td>
            </tr>
            <tr>
              <td width="100%" style="height:1px" bgcolor="#DADADA" valign="top"></td>
            </tr>
            <tr>
            
            <td width="100%" style="height:100%" valign="top">
            
              
			<div  style="margin-top:10px ;margin-left:13px; width:400" align="justify" class="m_text">HUMAN FORCE recrute pour le compte d’une société Multinational Asiatique Multisectoriels</div>
              <div style="margin-left:13px; margin-top:15px; margin-right:26px; margin-bottom:20px">
			
                <table style="background:url(/images/sigleannonce.gif) top left no-repeat;" width="400"  border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%"  valign="top"><div align="right" class="m_text Style5"><strong><u>REF: ADC64 </u> </strong></div>
                        <div align="center"  class="l_text Style4" style="margin-top:30px ; margin-left:45px; margin-right:25px">
                          <p>Attaché de Direction Commercial</p>
                        </div>
                      <div  style="margin-top:10px ;margin-left:42px" align="justify" class="m_text"></div>
                      <div align="justify" class="m_text"  style="margin-top:10px ;margin-left:32px"><strong>VOTRE MISSION</strong> : </div>
                      <div align="justify" class="m_text"  style="margin-top:5px ;margin-left:32px">• Suivi de l'activité de commerce et d'investissement du siège social de notre client sis au berge du lac II en Tunisie:<br>
• Assister à des communications entre les départements d'affaires de notre client et les acheteurs / vendeurs concernant la commande, les procédures de paiement, l'expédition, la livraison uniquement en anglais.<br>
• négocier les conditions de vente / achat / investissement (telles que le prix et les conditions de paiement)<br>
• La Surveillance des activités des agents de vente, des distributeurs et des projets d'investissement<br>
• La Faire des études de marché et des rapports.<br>
• Collaborer avec des ministères / organisations / entreprises pour un sondage sur le marché et Identifier les acheteurs potentiels / vendeurs / partenaires.<br>
• Accueillir les délégations étrangères de Mitsubishi Corporation et / ou ses sociétés affiliées et Organiser les rendez-vous / Assister et assister aux réunions pour les délégations ci-dessus.<br>
• Interpréter en direct et traduction de documents (le cas échéant) à partir des langues anglais, français et arabe<br>
• La garantie d’une veille concurrentielle et le reporting régulier</div>
                      <div align="justify" class="m_text"  style="margin-top:10px ;margin-left:32px"><strong>VOTRE PROFIL :</strong> </div>
                      <div align="justify" class="m_text"  style="margin-top:5px ;margin-left:32px">Formation initiale : Master (Branche Economique/Commerciale)<br>
Formation complémentaire : Anglais Commercial.<br>
• Votre anglais est impérativement courant<br>
• Expérience souhaitée : 2-3 ans dans une société commerciale, de préférence étrangère<br>
• Informatique : Connaissance de base (Word,Exc,PP). Autres indispensable. <br>
•	Langues : Maitrise de l’Anglais, du Français et de l’Arabe<br>
•	Jeune et présentable. (35 ans Max.)<br>
•	Caractère compatible avec l’esprit du travail solidaire et en groupe.(Team Work).<br>
•	 Bonne connaissance des aspects économiques de la Tunisie et de sa relation avec son environnement économique régional et International (Maghreb Arabe, Union Européenne, Organisations mondiales, etc…)  <br>
•	Bonne culture générale.<br>
Vos qualités de communication, votre dynamisme et une excellente présentation vous permettront également de réussir le challenge proposé
</div>
					  
					  <div align="right" class="l1_text"  style="margin-top:15px ;margin-left:32px"><strong><a href="/index-7.php" class="l1_text">POSTULEZ</a> </strong></div>
					  
                      <div style="margin-left:px; margin-top:10px"align="right"><img src="/images/bordurebashf.gif"></div></td>
                  </tr>
                </table>
              </div>
                
			<div  style="margin-top:10px ;margin-left:13px; width:400" align="justify" class="m_text">HumanForce recrute pour le compte d’une startup dans le domaine de la télécom un Développeur Mobile IOS et Android. </div>
              <div style="margin-left:13px; margin-top:15px; margin-right:26px; margin-bottom:20px">
			
                <table style="background:url(/images/sigleannonce.gif) top left no-repeat;" width="400"  border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%"  valign="top"><div align="right" class="m_text Style5"><strong><u>REF: DIA845 </u> </strong></div>
                        <div align="center"  class="l_text Style4" style="margin-top:30px ; margin-left:45px; margin-right:25px">
                          <p>Développeur mobile IOS & Android</p>
                        </div>
                      <div  style="margin-top:10px ;margin-left:42px" align="justify" class="m_text"></div>
                      <div align="justify" class="m_text"  style="margin-top:10px ;margin-left:32px"><strong>VOTRE MISSION</strong> : </div>
                      <div align="justify" class="m_text"  style="margin-top:5px ;margin-left:32px">A ce titre, votre fonction consistera à :<br>
• Participer aux phases d'architecture et de conception technique,<br>
• Développer des applications/composants/services en Java Android, Swift, en respectant les contraintes techniques <br>
• Tester unitairement les composants réalisés,<br>
• Optimiser les performances,<br>
• Participer aux phases d'assemblage et de mise au point des applications,<br>
• analyser et corriger les anomalies détectées<br>
• garantir la livraison et le déploiement des applications<br>
• assurer la maintenance évolutive et/ou corrective<br>
• veiller au respect des normes et des procédures en vigueur (architecture, sécurité, qualité et documentation)</div>
                      <div align="justify" class="m_text"  style="margin-top:10px ;margin-left:32px"><strong>VOTRE PROFIL :</strong> </div>
                      <div align="justify" class="m_text"  style="margin-top:5px ;margin-left:32px">De formation supérieure en Informatique, vous bénéficiez d’une expérience significative et spécialisé d’au moins 2 ans dans le développement d'applications mobiles natives Android et iOS. Vous maîtrisez les environnements IOS et/ou Android et les éditeurs Xcode et Android studio et êtes sensible à la qualité du code<br><br>
 
Rigoureux (se) et organisé (e), vous avez l’esprit d’analyse et de synthèse ainsi que le goût du travail en équipe. Investi (e), votre curiosité technique et vos acquis vous permettent d’appréhender efficacement les différentes missions qui vous sont confiées, et vous permettent de progresser rapidement sur les différentes technologies que vous utilisez.<br><br>
 Votre sens du service, votre esprit d'équipe, votre autonomie, votre relationnel et votre curiosité sont des atouts essentiels qui vous permettront de mener à bien les missions qui vous seront confiées
</div>
					  
					  <div align="right" class="l1_text"  style="margin-top:15px ;margin-left:32px"><strong><a href="/index-7.php" class="l1_text">POSTULEZ</a> </strong></div>
					  
                      <div style="margin-left:px; margin-top:10px"align="right"><img src="/images/bordurebashf.gif"></div></td>
                  </tr>
                </table>
              </div>
                
			<div  style="margin-top:10px ;margin-left:13px; width:400" align="justify" class="m_text">HUMAN FORCE recrute pour le compte d’une société Multinational pétrolière dans le domaine de la distribution du pétrole</div>
              <div style="margin-left:13px; margin-top:15px; margin-right:26px; margin-bottom:20px">
			
                <table style="background:url(/images/sigleannonce.gif) top left no-repeat;" width="400"  border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="100%"  valign="top"><div align="right" class="m_text Style5"><strong><u>REF: MCM694 </u> </strong></div>
                        <div align="center"  class="l_text Style4" style="margin-top:30px ; margin-left:45px; margin-right:25px">
                          <p>MIDDEL MANAGER Marketing</p>
                        </div>
                      <div  style="margin-top:10px ;margin-left:42px" align="justify" class="m_text"></div>
                      <div align="justify" class="m_text"  style="margin-top:10px ;margin-left:32px"><strong>VOTRE MISSION</strong> : </div>
                      <div align="justify" class="m_text"  style="margin-top:5px ;margin-left:32px">Directement rattaché au Directeur Général, vos responsabilités seront les suivantes : <br>
• La définition de la politique MARKETING <br>
• L’établissement et le suivi du budget<br> 
• Le management et l’animation de l’équipe MARKETING<br>
• La gestion des contrats et des événements<br>
• La mise en place et la coordination des moyens de communication<br>
• La diffusion des informations techniques et commerciales<br>
• L’application, la surveillance et l’amélioration des processus <br>
• Développement de la stratégie marketing et de nouveaux produits<br>
• La garantie d’une veille concurrentielle et le reporting régulier</div>
                      <div align="justify" class="m_text"  style="margin-top:10px ;margin-left:32px"><strong>VOTRE PROFIL :</strong> </div>
                      <div align="justify" class="m_text"  style="margin-top:5px ;margin-left:32px">De formation supérieure marketing, vous justifiez d’au moins 7 années d’expérience au sein d’une structure internationale, dont 3 ans minimum dans un poste de responsabilité ;<br>
• Votre anglais est impérativement courant<br>
• Vous avez développé de réelles capacités à prospecter un marché et à saisir des opportunités.<br>
• Vos qualités de communication, votre dynamisme et une excellente présentation vous permettront également de réussir le challenge proposé</div>
					  
					  <div align="right" class="l1_text"  style="margin-top:15px ;margin-left:32px"><strong><a href="/index-7.php" class="l1_text">POSTULEZ</a> </strong></div>
					  
                      <div style="margin-left:px; margin-top:10px"align="right"><img src="/images/bordurebashf.gif"></div></td>
                  </tr>
                </table>
              </div>
                          <div style="margin-left:13px; margin-top:15px; margin-right:26px; margin-bottom:20px">
            
            <table  width="200"  border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>

                <td width="30px"  class="m_text" valign="top"> </td>


                <td width="70px"  valign="top" class="m_text"></td>

				

                <td width="70px"  valign="top" class="m_text"><div align="right">
                                      <a href="/candidat/offre-emploi-human-force.php?pageNum_offrenligne=1&totalRows_offrenligne=53"><strong>Suivant &gt;</strong></a>
                    </div></td>

                

                <td width="30px"  valign="top" class="m_text"><div align="right"> 
                                      <a href="/candidat/offre-emploi-human-force.php?pageNum_offrenligne=17&totalRows_offrenligne=53"><strong>&gt;&gt;</strong></a>
                    </div></td>

              </tr>
              
            </table>
            </div>
            
            </td>
            
            </tr>
            
          </table>
          </td>
          
          </tr>
          
          <tr>
            <td width="100%" style="background-image: url(../images/b-dr.gif); background-repeat: repeat-x; height:59px" valign="top"><div style="margin-left:17px; margin-top:20px; margin-right:px; margin-bottom:px">
              <form id="form1" action="interimaire-human-force.php" enctype="multipart/form-data" name="form1" style="margin:0px; padding:0px">
                <table width="366" style="height:px" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="184" style="height:px" valign="top"><div style="margin-left:px; margin-top:px;"><img alt="" border="0" src="../images/t4.gif"></div></td>
                    <td width="141" style="height:px" valign="top"><input type="text" class="form1 m_text" value="Entrer votre email" style="color:#6A6A6A"></td>
                    <td width="41" style="height:px" valign="top"><input type="image" src="../images/ok.gif"></td>
                  </tr>
                </table>
              </form>
            </div></td>
          </tr>
        </table>
        </td>
        
        <td width="7" style="height:425px" valign="top"><div><img  src="../images/spacer.gif" alt="" width="7" height="1"  border="0"></div></td>
        </tr>
      </table>
    </td>
    
    </tr>
    
    <tr>
      <td width="100%" style="height:39px" valign="top"></td>
    </tr>
  </table>
  </td>
  
  <td width="48" style="height:464px" valign="top"><div style="margin-left:px; margin-top:px;"><img alt="" border="0" src="../images/r.gif"></div></td>
  </tr>
        </table>
		</td>
	    </tr>
	</table>
</body>
</html>
