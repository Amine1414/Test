
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>Information</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	   <link rel="stylesheet" media="screen" type="text/css" title="Design" href="styles/calcul_irg.css" />
   </head>
   <body class=fond>

	<div class="pub">

	<div class="logo">
	<!-- Logo -->
	</div>

	<h2>NTIC SOFT</h2>
	<div class="centrer">Ing�nierie des syst�mes,</div>
	<div class="centrer">Informatique</div>
	<div class="centrer">et</div>
	<div class="centrer">services internet</div><br/>
	<div class="centrer1">T�l : 0550.11.77.88</div>
	<div class="decal1">0550.11.34.34</div><br/>
	<div class="email">info@nticsoft.com</div><br/>
	<div class="info">Pour toutes informations sur nos diff�rents produit, veuiller visiter notre site web <a href="http://www.nticsoft.com" target="_blank" >nticsoft.com</a> et <a href="http://www.nticsoft.net" target="_blank" >nticsoft.net</a></div>


	</div>

    <div id="menu">
	<ul id="onglets">
		<li><a href="information.php"> Informations </a></li>
		<li class="active"><a href="calculette_IRG.php"> Calculette IRG </a></li>
		<li><a href="calcul_paie_inverse.php"> Calcul paie inverse </a></li>
	</ul>
	</div>
   <br/> <br/> <br/>

   <table>

   <tr>
   <th class="titre" colspan="2" height="30px" width="600px"> CALCULATRICE IRG </th>
   </tr>

    <form method="post" action="calculette_IRG.php">
	<tr>
	<td>
		<p>
		   <label>Base soumise a l'IRG :</label> <input type="text" name="base_irg" maxlength="10"  />
		</p>
		<p>
		   <label>R�sultat :</label> <input type="text" name="resultat"  />
	    </p>
	</td>
	<td align="center">
		<input type="submit" value="Calculer" name="calcIRG"/>
	</td>
	</tr>
	</form>


	<form method="post" action="calculette_IRG.php">
	<tr>
	<td>
	   <p>
		   <label>Borne Inf :</label> <input type="text" name="borne_inf" maxlength="6" />
	   </p>
	   <p>
		   <label>Borne Sup :</label> <input type="text" name="borne_sup" maxlength="6" />
	   </p>
	</td>

	<td align="center">
       <input type="submit" value="Editer" name="editer" />
    </td>
	</tr>
	</form>

   </table>

    <div class="fermer">
	<input TYPE="button" value="Fermer la fen�tre" onClick="parent.close()" />
	</div>

   </body>
</html>

