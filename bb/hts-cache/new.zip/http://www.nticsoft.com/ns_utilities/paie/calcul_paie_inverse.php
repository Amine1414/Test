
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>Information</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	   <link rel="stylesheet" media="screen" type="text/css" title="Design" href="styles/calcul_paie_inverse.css" />
   </head>
   <body class=fond >

	<div class="pub">

	<div class="logo">
	<!-- Logo -->
	</div>

	<h2>NTIC SOFT</h2>
	<div class="centrer">Ing�nierie des syst�mes,</div>
	<div class="centrer">Informatique</div>
	<div class="centrer">et</div>
	<div class="centrer">services internet</div><br/>
	<div class="centrer1">T�l : 0550.11.77.88</div>
	<div class="decal1">0550.11.34.34</div><br/>
	<div class="email">info@nticsoft.com</div><br/>
	<div class="info">Pour toutes informations sur nos diff�rents produit, veuiller visiter notre site web <a href="http://www.nticsoft.com" target="_blank" >nticsoft.com</a> et <a href="http://www.nticsoft.net" target="_blank" >nticsoft.net</a></div>

	</div>

    <div id="menu">
	<ul id="onglets">
		<li><a href="information.php"> Informations </a></li>
		<li><a href="calculette_IRG.php"> Calculette IRG </a></li>
		<li class="active"><a href="calcul_paie_inverse.php"> Calcul paie inverse </a></li>
	</ul>
	</div>
   <br/> <br/> <br/>

   <table>
   <tr>
   <th class="titre" colspan="2" height="30px" width="600px">CALCUL INVERSE DE LA PAIE</th>
   </tr>
   </table>

   <div class="bloc1">

   <form method="post" action="calcul_paie_inverse.php">

   <div class="bloc12">
	    <p>
		   <label>Net � payer :</label><input type="text" name="net_a_payer1" maxlength="10"  />
	    </p>
   </div>

   <div class="bloc13">
	   <p class="bouton">
       <input type="submit" value="Calculer" name="calculer"/>
	   </p>
   </div>

   </form>

   </div>

   <table class="tabres">
   <tr>
   <th height="30px" width="150px">Rubrique</th>
   <th height="30px" width="150px">Base/Tx</th>
   <th height="30px" width="150px">Gain</th>
   <th height="30px" width="150px">Retenue</th>
   </tr>

   <tr height="20px" width="150px">
   <td>Salaire de base</td>
   <td style="text-align:center">-</td>
   <td style='text-align:center' >-</td>
   <td style="text-align:center" >-</td>
   </tr>

   <tr height="20px" width="150px">
   <td>Base Cotisable</td>
   <td style='text-align:center' >-</td>
   <td style="text-align:center" >-</td>
   <td style="text-align:center" >-</td>
   </tr>

   <tr height="20px" width="150px">
   <td>Retenue s�curit� social</td>
   <td style='text-align:right' >9.00</td>
   <td style='text-align:center' >-</td>
   <td style='text-align:center' >-</td>
   </tr>

   <tr height="20px" width="150px">
   <td>Base Imposable</td>
   <td style='text-align:center' >-</td>
   <td style="text-align:center" >-</td>
   <td style="text-align:center" >-</td>
   </tr>

   <tr height="20px" width="150px">
   <td>Retenue IRG</td>
   <td style='text-align:center' >-</td>
   <td style="text-align:center" >-</td>
   <td style='text-align:center' >-</td>
   </tr>

   </table>

		<p>
		   <label>Net � payer :</label><input type="text" name="net_a_payer2" readonly=true  />
		</p>

    <div class="fermer">
	<input type="button" value="Fermer la fen�tre" onClick="parent.close()" />
	</div>

   </body>
</html>
