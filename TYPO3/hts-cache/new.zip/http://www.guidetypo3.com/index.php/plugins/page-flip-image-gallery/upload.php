<!DOCTYPE html
     PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- 
	This website is powered by TYPO3 - inspiring people to share!
	TYPO3 is a free open source Content Management Framework initially created by Kasper Skaarhoj and licensed under GNU/GPL.
	TYPO3 is copyright 1998-2012 of Kasper Skaarhoj. Extensions are copyright of their respective owners.
	Information and contribution at http://typo3.org/
-->

<base href="http://www.guidetypo3.com/" />


<meta name="generator" content="TYPO3 4.5 CMS" />
<meta name="keywords" content="guidetypo3, guide typo3, typo3, typo3 tutorial, typo3 news, actualité typo3, typo3 templates, typo3 typoscript, typo3 extensions, typo3 guide, typo3 help, typo3 download" />
<meta name="description" content="guidetypo3 est un site d'actualité de TYPO3 dans le monde, il contient différents tutoriaux simples et faciles, des news, des trucs et astuces, la description des principaux extensions typo3, téléchargement des templates typo3 gratuits" />

<link rel="stylesheet" type="text/css" href="http://www.guidetypo3.com/typo3conf/ext/t3s_jslidernews/res/css/style6.css?1327777280" media="all" title="stylesheet" />
<link rel="stylesheet" type="text/css" href="http://www.guidetypo3.com/typo3temp/stylesheet_7365c95366.css" media="all" />
<style type="text/css">
/*<![CDATA[*/
<!-- 
/* CSS for EXT t3s_jslidernews */
.lof-main-item-desc {width:892px; bottom:0px; left:0px; } .lof-main-item-desc h3 {font-size:100%;}
-->
/*]]>*/
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js" type="text/javascript"></script>
<script src="http://www.guidetypo3.com/typo3conf/ext/t3s_jslidernews/res/js/jquery.easing.js?1327777280" type="text/javascript"></script>
<script src="http://www.guidetypo3.com/typo3conf/ext/t3s_jslidernews/res/js/jslidernews.js?1327777280" type="text/javascript"></script>
<script src="http://www.guidetypo3.com/typo3temp/javascript_93077bb238.js" type="text/javascript"></script>
<script type="text/javascript">
/*<![CDATA[*/
<!-- 
/* JavaScript for EXT t3s_jslidernews */
var j=jQuery.noConflict();j(document).ready(function(){var buttons={previous:j('#lofslidecontent45 .lof-previous'),next:j('#lofslidecontent45 .lof-next')};$obj=j('#lofslidecontent45').lofJSidernews({interval:6000,direction:'opacity',easing:'easeInOutExpo',maxItemDisplay:3,duration:2000,auto:true,mainWidth:912,buttons:buttons});});
// -->
/*]]>*/
</script>

<title>TYPO3 - CMS libre et open source&nbsp;- Guide TYPO3</title><meta name="google-site-verification" content="P5N2kwd9qFWmwwCZr22GfvdUvUE7DflBQcVVl9GGKac" /><meta name="copyright" content="guidetypo3 2010 - Tous droits réservés" /><meta http-equiv="content-language" content="fr-FR" />
	<link rel="stylesheet" href="http://www.guidetypo3.com/fileadmin/templates/v1/css/style-v11.css" type="text/css" media="all" />
        <link rel="shortcut icon" href="http://www.guidetypo3.com/fileadmin/templates/v1/images/favicon.ico" />
        <!-- begin accordion -->
        <!-- begin dragtoshare -->
	<link rel="stylesheet" type="text/css" href="http://www.guidetypo3.com/fileadmin/templates/flexibles_contents/dragtoshare/dragToShare-v1.css" />
	<script src="http://www.guidetypo3.com/fileadmin/templates/flexibles_contents/dragtoshare/dragToShare14.js" type="text/javascript"></script>
	<!-- end dragtoshare -->
	<script src="http://www.guidetypo3.com/fileadmin/templates/v1/js/jquery-ui.js" type="text/javascript"></script>
	<script src="http://www.guidetypo3.com/fileadmin/templates/v1/js/scrolltopcontrol.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(function() {
			$('#recap').accordion();
		});
	</script>
	<!-- end accordion -->
        <!-- begin display -->
	<script type="text/javascript">
		$(function(){
			$('#news').hover(
			// on hover
			function(){
				$(".filter").animate({ 
					opacity: 1
				}, 500 );
			},
			// on quit
			function(){
				$(".filter").animate({ 
					opacity: 0
				}, 500 );
			});
		});
		$(function(){
			$('.filter li a').click(function(){
				// Figure out current list via CSS class
				var curList = $(".filter li a.active").attr("rel");
				
				// List moving to
				var $newList = $(this);
				
				// Remove highlighting - Add to just-clicked tab
				$(".filter li a").removeClass("active");
				$newList.addClass("active");
				
				$("#list_news").animate({ 
					opacity: 0
				}, 500, function() {
					$("#list_news").removeClass();
					$("#list_news").addClass("entryblock_"+$newList.attr("id"));
				});
				$("#list_news").animate({ 
					opacity: 1
				}, 500 );
			});
		});
		
		/* attempt to find a text selection */
		function getSelected() {
			if(window.getSelection) { return window.getSelection(); }
			else if(document.getSelection) { return document.getSelection(); }
			else {
				var selection = document.selection && document.selection.createRange();
				if(selection.text) { return selection.text; }
				return false;
			}
			return false;
		}
		/* create sniffer */
		$(document).ready(function() {
			var url = 'http://www.guidetypo3.com/recherche/mots-cles/{term}', selectionImage;
			$('.container').mouseup(function(e) {
				var selection = getSelected();
				if(selection && (selection = new String(selection).replace(/^\s+|\s+$/g,''))) {
					//ajax here { http://davidwalsh.name/text-selection-ajax }
					if(!selectionImage) {
						selectionImage = $('<a>').attr({
							href: url, 
							title: 'Cliquez ici pour rechercher ce terme',
							target: '_blank',
							id: 'selection-image'
						}).hide();
						$(document.body).append(selectionImage);
					}
					selectionImage.attr('href',url.replace('{term}',encodeURI(selection))).css({
						top: e.pageY - 30,	//offsets
						left: e.pageX - 13 //offsets
					}).fadeIn();
				}
			});
			$(document.body).mousedown(function() {
				if(selectionImage) { selectionImage.fadeOut(); }
			});
			
			jQuery.fn.nudge=function(a){
				a=jQuery.extend({amount:20,duration:300,property:"padding",direction:"left",toCallback:function(){},fromCallback:function(){}},a);
				this.each(function(){
					var h=jQuery(this);
					var e=a;
					var d=e.direction;
					var g=e.property+d.substring(0,1).toUpperCase()+d.substring(1,d.length);
					var c=h.css(g);
					var f={};
					f[g]=parseInt(e.amount)+parseInt(c);
					var b={};b[g]=c;h.hover(function(){h.stop().animate(f,e.duration,"",e.toCallback)},function(){h.stop().animate(b,e.duration,"",e.fromCallback)})
				});
				return this
			};

		});

	</script>
	<!-- end display -->
	<style type="text/css">
	.titre-actu {background-position:left center;background-repeat:no-repeat;padding-left:36px;}
	span.flecheLeft {float:left;}
	span.flecheRight, .bt-submit {float:right;}
	span.flecheLeft a {background:url("/fileadmin/templates/v1/images/nav-bg-left.png") no-repeat scroll 8px center #F6F6F6;padding:5px 10px 5px 25px;}
	span.flecheRight a {background:url("/fileadmin/templates/v1/images/nav-bg-right.png") no-repeat scroll right center #F6F6F6;padding:5px 25px 5px 10px;}
	span.flecheLeft a, span.flecheRight a, .bt-submit {-moz-border-radius:5px;border:1px solid #E5E5E5;display:block;color:#333333;}
	span.flecheLeft a:hover, span.flecheRight a:hover, input.bt-submit:hover {border-color:#D3D3D3;}
	
	.guestbook {margin:10px;}
	ul.commentInputs {overflow:hidden;}
	ul.commentInputs li {float:left;margin-left:5px;width:220px;}
	ul.commentInputs li label, .comments-field label {color:#6A6A6A;}
	ul.commentInputs li input.mid, .comments-field  textarea {background:none repeat scroll 0 0 #F8F8F8;border:1px solid #E3E3E3;color:#6A6A6A;padding:4px;}
	ul.commentInputs li input.mid {width:200px;}
	.comments-field {padding:10px 10px 15px 5px;}
	.bt-submit {padding:4px;}
	
	.error-bloc {background-position:5px 5px;border:1px solid #D25F66;
background-repeat:no-repeat;color:#2E2D2D;margin:10px 10px 15px 5px;display:none;
background-color: #FFBABA; -moz-border-radius-topleft: 18px; -moz-border-radius-topright: 18px; -moz-border-radius-bottomright: 18px; -moz-border-radius-bottomleft: 18px;
background-image: url("http://1.bp.blogspot.com/_5rlxf3T9Z9U/SsIX7-C1GYI/AAAAAAAADco/5XubUJ34o2c/warning_32.png");}
	.error-bloc p {font-weight:bold;padding-bottom:10px;padding-left:40px;padding-top:10px;}
	.error-bloc ul {padding-bottom:5px;padding-left:40px;}
	.error-bloc ul li {list-style:decimal outside none;}
	
	.no-comment {background:none repeat scroll 0 0 #F6F6F6;
border:1px solid #E5E5E5;color:#6A6A6A;display:block;height:14px;
line-height:14px;margin:15px 0 10px;padding:10px;text-align:center;
-moz-border-radius:5px 5px 5px 5px;}

	.align-center {text-align:center;}
	.align-center img {-moz-box-shadow:0 0 8px #555555;margin:10px 0;}
	
	.noStyle {}
	.noStyle .auteur {color:#999999;}
	.noStyle ul {margin:5px 0 15px 30px;}
	.noStyle ul li {list-style:disc outside none;margin:0 0 2px;color:#000000;}
	
	.noStyle h2 {color:#669933;font-family:Calibri,Arial,Helvetica,sans-serif;font-size:1.2em;padding-top:10px;}
	.noStyle h3 {background-image:url("/fileadmin/templates/v1/images/bullet_triangle_2.gif");background-position:left 10px;background-repeat:no-repeat;padding-left:12px;color:#FF8700;font-family:Calibri,Arial,Helvetica,sans-serif;font-size:16px;padding-top:4px;}
	
	*::-moz-selection {
		background-color:#FFFF00;
		color:#000000;
	}
	
	#selection-image {
		background:transparent url(http://graphics8.nytimes.com/images/global/word_reference/ref_bubble.png) no-repeat scroll 0 0;
		height:29px;
		position:absolute;
		width:25px;
		z-index:2000;
	}
	
	.bloc-page {height:70px;margin:5px;padding:10px;float:left;position:relative;width:305px;display:block;border:5px solid #DDDDDD;}
	.bloc-page-news {border: 5px solid #DDDDDD;display: block;float: left;margin: 3px;padding: 8px;position: relative;width: 142px;}
	.bloc-page img {float:left;padding-right:5px;}
	.bloc-page-news img {padding-right:5px;}
	.bloc-page h2 {padding-bottom:5px;font-size:18px;}
	.bloc-page-news h2 {font-size:18px;padding-top: 0px;}
	.bloc-page p {font-size:14px;}
	.bloc-page-news p {font-size:14px;text-align: center;padding-top: 5px;}
	.bloc-page:hover, .bloc-page-news:hover {border-color:#CCCCCC;}
	
	.left_container ul, .left_container li {color:#FF8700;padding:0;}
	.left_container ul li a {color:#333333;}
	.left_container ul li a:hover {color:#FF8700;}

	.contact_form .contact_gauche .meta_contact img {position:relative;right:0;top:0;border:0 none;}
	.menu-page {padding:10px 20px !important;}
	
	.csc-sitemap ul {margin:10px 10px 10px 20px !important;}
	.csc-sitemap ul li {list-style:square outside none !important;margin:5px 0 !important;}
	.csc-sitemap ul li ul {margin:0px 10px 0px 20px !important;}
	
	.menu-page {border:1px solid #D3D3D3;}
	
	#tx_codehighlight_pi1 {}
	#tx_codehighlight_pi1 ol {-moz-border-radius:10px 10px 10px 10px;background-color:#EEEEEE;border:1px solid #D3D3D3;padding:10px;}
	#tx_codehighlight_pi1 .code {}
	#tx_codehighlight_pi1 .typoscript {}
	#tx_codehighlight_pi1 .li2 {color:#000000;}
	#tx_codehighlight_pi1 .li2 a {color:#000000;}
	
	.scrollContainer {}
	.scrollContainer ul {}
	.scrollContainer ul li {color:#000000;list-style:square outside none;margin-left:15px;padding:5px 0 5px 5px;}
	
	.tx-newsfeedit-pi1-form-row-datetime {display:none !important;}
	.scrollButtons {display:none;}
	
	.news-list-browse {clear:both;display:block;text-align:center;}
	.icon_file {background-image:url("/fileadmin/templates/v1/images/download.png");display: block;float: left;height: 16px;margin-right: 5px;position: relative;width: 16px;}
	.down_file a {margin-right: 5px;}
	.file_download {color: #669933;font-weight: bold;}
	.hidelegende {padding-top:20px;}
	.hidelegende legend {display:none;}

	.tx-ttnews-browsebox td {margin-right: 2px;padding: 2px 5px;text-decoration: none;background-color:#999999;border: 1px solid #2C2C2C;}
	.tx-ttnews-browsebox-SCell {background-color:#AAD83E !important;border: 1px solid #669933 !important;}
	.tx-ttnews-browsebox td a {color: #FFFFFF;}
	.tx-ttnews-browsebox {text-align: center;}
	.tx-ttnews-browsebox table {display: inline;}
	
	.btnProposer {
		background:url("http://www.guidetypo3.com/fileadmin/images/btn/btn-vide.png") no-repeat scroll 0 0 transparent;
		clear:both;
		color:#FFFFFF;
		display:block;
		font-size:16px;
		font-weight:bold;
		height:25px;
		margin-bottom:5px;
		margin-top:4px;
		padding-left:30px;
		padding-top:5px;
		position:relative;
		text-align:left;
		width:150px;
	}
	
	.lof-slidecontent {margin-bottom: 5px;}
	.lof-main-item-desc, .lof-main-item-desc a {color: #FFFFFF !important;}
	
	.news-single-img {padding: 5px 0 10px;}
	.news-single-img img {box-shadow: 0 0 8px #555555;margin: 10px 0;}
	
	#googleAdSense {text-align:center;padding-top:10px;}
	
	@media print
  	{
  		.header, .top_container, .bottom_container, .right_container, .footer, #topcontrol {display:none;}
  		.left_container, .container, .global_container, .global {display:table;float:none;position:relative;}
  	}
	</style>
	
	<script src="http://www.guidetypo3.com/fileadmin/templates/v1/js/jquery.lazyload.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" charset="utf-8">
		$(function() {          
			$("img").lazyload({
				placeholder : "http://www.guidetypo3.com/fileadmin/templates/v1/images/grey.gif",
				effect      : "fadeIn"
			});
			$(".partage").nudge({property:"top",direction:"",amount:-10,duration:166});
		});
	</script>
	
	<!-- Placez cette balise dans la section <head> ou juste avant la balise de fermeture </body> -->
	<script type="text/javascript" src="https://apis.google.com/js/plusone.js">
  		{lang: 'fr'}
	</script>
	
	
	<link rel="alternate" type="application/rss+xml" title="RSS" href="feed.html" />
	
		
	<style type="text/css">
	#left-column {width:600px;float: left;}
	#right-column {float: right;margin-left: 7px;width: 320px;}
	.box-title {background-image: url("/fileadmin/templates/v1/images/box_title.png");background-position: right center;color: #FFFFFF;font-weight: bold; height: 43px;line-height: 32px;padding-left: 8px;}
	.box-content {position: relative;top: -7px;width: 283px;}
	.left_container {padding: 0 0 0 5px !important;float: none !important;}
	.container {padding: 0 0 8px 7px !important;}
	</style><script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-16108840-1");
pageTracker._trackPageview();
} catch(err) {}</script>


</head>
<body>


  <div class="global">
    <div class="header">
      <a href="http://www.guidetypo3.com/" title="Guide TYPO3" class="logo"><img title="Guide TYPO3" alt="Guide TYPO3" src="/fileadmin/templates/v1/images/logo.png" /></a>
      <div class="share-rs">	<a target="_blank" href="feed.html" class="partage rss"></a>
	<a target="_blank" href="http://www.facebook.com/Guide.Typo3" class="partage fb"></a>
	<a target="_blank" href="http://twitter.com/guidetypo3" id="hovercard" title="@guidetypo3" class="partage tw"></a>
	<a target="_blank" href="/" class="partage bg"></a></div>
    </div>
    <div class="home_container">
      <div class="top_container">
        <ul class="top_menu"><li><a href="http://www.guidetypo3.com/" onfocus="blurLink(this);">Accueil</a></li><li><a href="http://www.guidetypo3.com/extensions.html" onfocus="blurLink(this);">Extensions</a></li><li><a href="http://www.guidetypo3.com/trucs-et-astuces.html" onfocus="blurLink(this);">Trucs et astuces</a></li><li><a href="http://www.guidetypo3.com/tutoriaux.html" onfocus="blurLink(this);">Tutoriaux</a></li><li><a href="http://www.guidetypo3.com/typoscript.html" onfocus="blurLink(this);">Typoscript</a></li><li><a href="http://www.guidetypo3.com/telechargements.html" onfocus="blurLink(this);">Téléchargements</a></li><li><a href="http://www.guidetypo3.com/contact.html" onfocus="blurLink(this);">Contact</a></li></ul>
        <div class="search"><form action="http://www.guidetypo3.com/recherche.html" name="Recherche" method="post" style="float:right;">
        	<p>
        		<input type="text" name="tx_indexedsearch[sword]" class="text" />
			<input type="hidden" name="tx_indexedsearch[pointer]" value="0" />
			<input type="hidden" name="tx_indexedsearch[defOp]" value="1" />
			<input type="hidden" name="tx_indexedsearch[ext]" value="1" />
			<input type="hidden" name="tx_indexedsearch[results]" value="10" />
			<input type="hidden" name="tx_indexedsearch[lang]" value="0" />
			<input type="hidden" name="tx_indexedsearch[type]" id="tx-indexedsearch-selectbox-type" value="1" />
        		<input type="submit" value="OK" class="submit" />
        	</p>
        </form></div>
      </div>
      <div class="container">
        <div class="left_container"><!--TYPO3SEARCH_begin--><div id="c97" class="csc-default"><div class="tx-t3sjslidernews-pi1">
		
<div id="lofslidecontent45" class="lof-slidecontent" style="width:912px; height:195px;">
  <div class="preload" style="width:912px; height:195px;"><div style="width:912px; height:195px;">&nbsp;</div></div>
  <div class="lof-main-outer" style="width:912px; height:195px;">
    <div onclick="return false" class="lof-previous">Previous</div>
  	<ul class="lof-main-wapper" style="width:912px; height:195px;">
	  
      <li class="mainItemSelector">
        <img src="http://www.guidetypo3.com/uploads/tx_t3sjslidernews/sommet.jpg" width="910" height="195" border="0" alt="" />           
        <div class="lof-main-item-desc">
  				<h3>Trucs et asctuces</h3>
          
          <a href="http://www.guidetypo3.com/?id=5" class="internal-link">Aller jusqu'au bout avec TYPO3</a> &nbsp; &nbsp;
        </div>
      </li> 
 	  
      <li class="mainItemSelector">
        <img src="http://www.guidetypo3.com/uploads/tx_t3sjslidernews/extensions.jpg" width="910" height="195" border="0" alt="" />           
        <div class="lof-main-item-desc">
  				<h3>Extensions</h3>
          
          <a href="http://www.guidetypo3.com/?id=3" class="internal-link">Paramétrer facilement les principaux extensions</a> &nbsp; &nbsp;
        </div>
      </li> 
 	  
      <li class="mainItemSelector">
        <img src="http://www.guidetypo3.com/uploads/tx_t3sjslidernews/actu.jpg" width="910" height="195" border="0" alt="" />           
        <div class="lof-main-item-desc">
  				<h3>Actualités</h3>
          
          <a href="http://www.guidetypo3.com/?id=4" class="internal-link">Suivre toutes les actualités TYPO3</a> &nbsp; &nbsp;
        </div>
      </li> 
 	  
    </ul>  	
    <div onclick="return false" class="lof-next">Next</div>
  </div>
</div> 

	</div>
	</div><div id="c79" class="csc-default">
  <div id="left-column"><div id="c30" class="csc-default">
<div class="border degrader padding" id="news">
  <ul class="filter" style="opacity: 0;">
    <li class="bypost"><a class="  active" id="bypost" title="Filtrer par article" onclick="return false;" href="http://www.guidetypo3.com/index.php/plugins/page-flip-image-gallery/upload.php#"></a></li>
    <li class="bylist"><a class=" " id="bylist" title="Filtrer par liste" onclick="return false;" href="http://www.guidetypo3.com/index.php/plugins/page-flip-image-gallery/upload.php#"></a></li>
    <li class="bymozaic"><a class=" " id="bymozaic" title="Filtrer par mozaïc" onclick="return false;" href="http://www.guidetypo3.com/index.php/plugins/page-flip-image-gallery/upload.php#"></a></li>
  </ul>
<div class="entryblock_bypost" id="list_news" style="opacity: 1;">
    
  <div class="entry dotted dragtoshare">
    <h2><a href="http://www.guidetypo3.com/actualite/article/demarrage-de-la-t3uni13.html" title="Démarrage de la T3UNI13">Démarrage de la T3UNI13</a></h2>
    <p class="info"><span class="metadata">Publié le 24/06/2013 par&nbsp;haythoum</span></p>
    <a href="http://www.guidetypo3.com/actualite/article/demarrage-de-la-t3uni13.html" title="Démarrage de la T3UNI13"><img src="http://www.guidetypo3.com/uploads/pics/bandeau_t3uni13.png" width="440" height="168" border="0" alt="" /></a>
    <div class="contenu">
      L'université d'été Typo3 T3UNI13 viens d'être commencé par la keynote d'ouverture par notre ami Cyril Wolfangel, avec présentation générales des différents intervenants durant l'université, les différents sujets qui seront...
    </div>
    <div class="suite"><a href="http://www.guidetypo3.com/actualite/article/demarrage-de-la-t3uni13.html" title="Démarrage de la T3UNI13">Lire la suite</a></div>
  </div>  
      
  <div class="entry dotted dragtoshare">
    <h2><a href="http://www.blog-onext.fr/?p=302" target="_top" title="#T3UNIFR12 [Jour3] – TYPO3 et l’Open Data">#T3UNIFR12 [Jour3] – TYPO3 et l’Open Data</a></h2>
    <p class="info"><span class="metadata">Publié le 27/06/2012 par&nbsp;haythoum</span></p>
    <a href="http://www.blog-onext.fr/?p=302" target="_top" title="#T3UNIFR12 [Jour3] – TYPO3 et l’Open Data"><img src="http://www.guidetypo3.com/uploads/pics/t3uni12_09.png" width="440" height="191" border="0" alt="" /></a>
    <div class="contenu">
      Début de la conférence « TYPO3 et l’Open Data ».
#Acteurs du projet#
Plan.Net : Aurélien Grayo
#Origine du projet#
Plateforme TYPO3 Open Data (historique, description, future, …).
#Etudes de cas#
Open Data c’est mise en...
    </div>
    <div class="suite"><a href="http://www.blog-onext.fr/?p=302" target="_top" title="#T3UNIFR12 [Jour3] – TYPO3 et l’Open Data">Lire la suite</a></div>
  </div>  
      
  <div class="entry dotted dragtoshare">
    <h2><a href="http://www.blog-onext.fr/?p=299" target="_top" title="#T3UNIFR12 [Jour2] – Retour d’expérience sur un Intranet Collaboratif TYPO3">#T3UNIFR12 [Jour2] – Retour d’expérience sur un Intranet Collaboratif TYPO3</a></h2>
    <p class="info"><span class="metadata">Publié le 26/06/2012 par&nbsp;haythoum</span></p>
    <a href="http://www.blog-onext.fr/?p=299" target="_top" title="#T3UNIFR12 [Jour2] – Retour d’expérience sur un Intranet Collaboratif TYPO3"><img src="http://www.guidetypo3.com/uploads/pics/t3uni12.png" width="440" height="191" border="0" alt="" /></a>
    <div class="contenu">
      Début de la conférence « Retour d’expérience sur un Intranet Collaboratif TYPO3 ».
#Acteurs du projet#
IFSTTAR : Céline Goupil
#Origine du projet#
Fusion de deux établissements publics, donc nouvel organisme, procédures...
    </div>
    <div class="suite"><a href="http://www.blog-onext.fr/?p=299" target="_top" title="#T3UNIFR12 [Jour2] – Retour d’expérience sur un Intranet Collaboratif TYPO3">Lire la suite</a></div>
  </div>  
      
  <div class="entry dotted dragtoshare">
    <h2><a href="http://www.blog-onext.fr/?p=296" target="_top" title="#T3UNIFR12 [Jour2] – Les étapes d’une certification ISO9001">#T3UNIFR12 [Jour2] – Les étapes d’une certification ISO9001</a></h2>
    <p class="info"><span class="metadata">Publié le 26/06/2012 par&nbsp;haythoum</span></p>
    <a href="http://www.blog-onext.fr/?p=296" target="_top" title="#T3UNIFR12 [Jour2] – Les étapes d’une certification ISO9001"><img src="http://www.guidetypo3.com/uploads/pics/t3uni12_01.png" width="440" height="191" border="0" alt="" /></a>
    <div class="contenu">
      Début de la conférence « Les étapes d’une certification ISO9001 ».
#Acteurs du projet#
Agence Wseils : Alain Le Tanter
#Origine du projet#
La certification TYPO3 concerne l’intégrateur, par contre TYPO3 et la certification...
    </div>
    <div class="suite"><a href="http://www.blog-onext.fr/?p=296" target="_top" title="#T3UNIFR12 [Jour2] – Les étapes d’une certification ISO9001">Lire la suite</a></div>
  </div>  
      
  <div class="entry dotted dragtoshare">
    <h2><a href="http://www.blog-onext.fr/?p=293" target="_top" title="#T3UNIFR12 [Jour2] – Réussir sa mise à jour de TYPO3">#T3UNIFR12 [Jour2] – Réussir sa mise à jour de TYPO3</a></h2>
    <p class="info"><span class="metadata">Publié le 26/06/2012 par&nbsp;haythoum</span></p>
    <a href="http://www.blog-onext.fr/?p=293" target="_top" title="#T3UNIFR12 [Jour2] – Réussir sa mise à jour de TYPO3"><img src="http://www.guidetypo3.com/uploads/pics/t3uni12_02.png" width="440" height="191" border="0" alt="" /></a>
    <div class="contenu">
      Début de la conférence « Réussir sa mise à jour de TYPO3 ».
#Acteurs du projet#
Agence Web Site’nGo : Thomas Leroy et Yohann Cerdan
#Origine du projet#
Partir d’une version TYPO3 obsolète vers une version TYPO3 à...
    </div>
    <div class="suite"><a href="http://www.blog-onext.fr/?p=293" target="_top" title="#T3UNIFR12 [Jour2] – Réussir sa mise à jour de TYPO3">Lire la suite</a></div>
  </div>  
      
  <div class="entry dotted dragtoshare">
    <h2><a href="http://www.blog-onext.fr/?p=276" target="_top" title="#T3UNIFR12 [Jour1] – TYPO3 + Alfresco + AD (&amp; témoignage client)">#T3UNIFR12 [Jour1] – TYPO3 + Alfresco + AD (& témoignage client)</a></h2>
    <p class="info"><span class="metadata">Publié le 25/06/2012 par&nbsp;haythoum</span></p>
    <a href="http://www.blog-onext.fr/?p=276" target="_top" title="#T3UNIFR12 [Jour1] – TYPO3 + Alfresco + AD (&amp; témoignage client)"><img src="http://www.guidetypo3.com/uploads/pics/t3uni12_03.png" width="440" height="191" border="0" alt="" /></a>
    <div class="contenu">
      Début de la conférence sur TYPO3 + Alfresco + Active directory. Il s’agit d’un projet sur lequel Onext, groupe Sodifrance travaille actuellement (Ville de Caluire et Cuire). Un témoignage client est aussi au programme de cette...
    </div>
    <div class="suite"><a href="http://www.blog-onext.fr/?p=276" target="_top" title="#T3UNIFR12 [Jour1] – TYPO3 + Alfresco + AD (&amp; témoignage client)">Lire la suite</a></div>
  </div>  
      
  <div class="entry dotted dragtoshare">
    <h2><a href="http://www.blog-onext.fr/?p=248" target="_top" title="#T3UNIFR12 [Jour1] – Le projet TESSERACT">#T3UNIFR12 [Jour1] – Le projet TESSERACT</a></h2>
    <p class="info"><span class="metadata">Publié le 25/06/2012 par&nbsp;haythoum</span></p>
    <a href="http://www.blog-onext.fr/?p=248" target="_top" title="#T3UNIFR12 [Jour1] – Le projet TESSERACT"><img src="http://www.guidetypo3.com/uploads/pics/t3uni12_04.png" width="440" height="191" border="0" alt="" /></a>
    <div class="contenu">
      Début de la conférence sur TESSERACT par François Suter, membre de la core team (outil de listing universel) :
#Acteurs du projet#
Collaboration entre deux agences concurrentes (cobweb.ch & ecodev.ch),
Collaboration grâce à...
    </div>
    <div class="suite"><a href="http://www.blog-onext.fr/?p=248" target="_top" title="#T3UNIFR12 [Jour1] – Le projet TESSERACT">Lire la suite</a></div>
  </div>  
      
  <div class="entry dotted dragtoshare">
    <h2><a href="http://www.blog-onext.fr/?p=220" target="_top" title="#T3UNIFR12 [Jour1] – KeyNote d’Ouverture">#T3UNIFR12 [Jour1] – KeyNote d’Ouverture</a></h2>
    <p class="info"><span class="metadata">Publié le 25/06/2012 par&nbsp;haythoum</span></p>
    <a href="http://www.blog-onext.fr/?p=220" target="_top" title="#T3UNIFR12 [Jour1] – KeyNote d’Ouverture"><img src="http://www.guidetypo3.com/uploads/pics/t3uni12_05.png" width="440" height="191" border="0" alt="" /></a>
    <div class="contenu">
      Après un bon repas au R.U de Polytech’Savoie, les intervenants se préparent. Cyril Wolfangel, devant un amphithéâtre déjà bien rempli, s’est vu offrir le Haut de forme de M.Loyal pour ses excellents services d’animateur de...
    </div>
    <div class="suite"><a href="http://www.blog-onext.fr/?p=220" target="_top" title="#T3UNIFR12 [Jour1] – KeyNote d’Ouverture">Lire la suite</a></div>
  </div>  
    


		<!--
			List browsing box:
		-->
		<div class="tx-ttnews-browsebox">

			<table>
				<tr>
					
					<td class="tx-ttnews-browsebox-SCell" nowrap="nowrap"><p><a href="http://www.guidetypo3.com/">Page  1</a></p></td>
					<td nowrap="nowrap"><p><a href="http://www.guidetypo3.com/page/1.html">Page  2</a></p></td>
					<td nowrap="nowrap"><p><a href="http://www.guidetypo3.com/page/2.html">Page  3</a></p></td>
					<td nowrap="nowrap"><p><a href="http://www.guidetypo3.com/page/3.html">Page  4</a></p></td>
					<td nowrap="nowrap"><p><a href="http://www.guidetypo3.com/page/4.html">Page  5</a></p></td>
					<td nowrap="nowrap"><p><a href="http://www.guidetypo3.com/page/1.html">Suivant ></a></p></td>
				</tr>
			</table>
		</div>
</div>
</div>
</div></div>
  <div id="right-column"><div id="c94" class="csc-default">
<div class="small-box">
  <div class="box-title">Votez pour Typo3</div>
  <div class="box-content border degrader padding"><div id="c95" class="csc-default"><div style="text-align: center;"><iframe allowtransparency="true" frameborder="0" scrolling="no" src="http://bitnami.com/product/typo3/widget" style="border:none;width:230px; height:100px;"></iframe></div></div></div>
</div>
</div><div id="c80" class="csc-default">
<div class="small-box">
  <div class="box-title">Guide TYPO3 sur facebook</div>
  <div class="box-content border degrader padding"><div id="c81" class="csc-default"><iframe src="http://www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FGuide.Typo3&amp;width=282&amp;colorscheme=light&amp;show_faces=true&amp;stream=false&amp;header=false&amp;height=254" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:282px; height:256px;" allowtransparency="true"></iframe></div></div>
</div>
</div><div id="c82" class="csc-default">
<div class="small-box">
  <div class="box-title">Guide TYPO3 sur twitter</div>
  <div class="box-content border degrader padding"><div id="c83" class="csc-default"><script src="http://widgets.twimg.com/j/2/widget.js" type="text/javascript"></script>
<script type="text/javascript">
new TWTR.Widget({
  version: 2,
  type: 'profile',
  rpp: 4,
  interval: 6000,
  width: 280,
  height: 300,
  theme: {
    shell: {
      background: 'transparent',
      color: '#000000'
    },
    tweets: {
      background: 'transparent',
      color: '#669933',
      links: '#ff8800'
    }
  },
  features: {
    scrollbar: false,
    loop: false,
    live: false,
    hashtags: true,
    timestamp: false,
    avatars: false,
    behavior: 'all'
  }
}).render().setUser('guidetypo3').start();
</script></div></div>
</div>
</div><div id="c91" class="csc-default">
<div class="small-box">
  <div class="box-title">Offres d'emploi TYPO3</div>
  <div class="box-content border degrader padding"><div id="c92" class="csc-default"><p class="bodytext">Prochainement, nous ajouterons une nouvelle section dédiés aux offres d’emploi <b>TYPO3</b> dans le monde.</p>
<p class="bodytext"><b><a href="http://www.guidetypo3.com/proposer-une-offre-demploi.html" target="_top" class="internal-link">Cliquez ici</a></b> pour soumettre une nouvelle offre d’emploi <b>TYPO3</b>.</p>
<p class="bodytext"><a href="http://www.guidetypo3.com/offres-demploi.html" class="internal-link">Liste des offres d'emploi</a></p></div></div>
</div>
</div><div id="c84" class="csc-default">
<div class="small-box">
  <div class="box-title">Publicité Google</div>
  <div class="box-content border degrader padding"><div id="c85" class="csc-default"><div style="text-align: center;"><script type="text/javascript"><!--
google_ad_client = "ca-pub-7194859205088692";
/* Accueil */
google_ad_slot = "2462829485";
google_ad_width = 250;
google_ad_height = 250;
//-->
</script>
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script></div></div></div>
</div>
</div></div>
</div><div id="c31" class="csc-default"><ul id="targets" style="display:none;">
      <li id="twitter"><a href="http://twitter.com"><!-- --></a></li>
      <li id="delicious"><a href="http://delicious.com"><!-- --></a></li>
      <li id="facebook"><a href="http://www.facebook.com"><!-- --></a></li>
</ul></div><!--TYPO3SEARCH_end--></div>
      </div>
      <div class="bottom_container"></div>
    </div>
    <div class="footer">
      <div class="bottom_menu"><a href="http://www.guidetypo3.com/contact.html" onfocus="blurLink(this);"  >Nous contacter</a>&nbsp;&#124;&nbsp;<a href="http://www.guidetypo3.com/mentions-legales.html" onfocus="blurLink(this);"  >Mentions légales</a>&nbsp;&#124;&nbsp;<a href="http://www.guidetypo3.com/plan-du-site.html" onfocus="blurLink(this);"  >Plan du site</a><div style="margin-top:10px;"><a target="_blank" href="http://validator.w3.org/check?uri=http%3A%2F%2Fwww.guidetypo3.com"><img src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Transitional" width="88" height="31" border="0" /></a>&nbsp;<a target="_blank" href="http://jigsaw.w3.org/css-validator/validator?uri=http%3A%2F%2Fwww.guidetypo3.com"><img src="http://www.w3.org/Icons/valid-css" alt="Valid CSS" width="88" height="31" border="0" /></a></div></div>
      <div class="logo_typo3">
        <a href="http://www.planethoster.net/?a_aid=guidetyp&amp;a_bid=de9a8992" target="_blank"><img src="http://cdn.planethoster.net/images/bannieres/Fbutton-88x31-02.gif" border="0" alt="Hébergé par PlanetHoster" title="Hébergé par PlanetHoster" width="88" height="31" /></a><img style="border:0" src="http://affiliation.planethoster.info/scripts/imp.php?a_aid=guidetyp&amp;a_bid=de9a8992" width="1" height="1" alt="" />
        <a href="http://typo3.org/" target="_blank"><img src="http://www.guidetypo3.com/fileadmin/templates/v1/images/logo_typo3.png" alt="Réalisé avec TYPO3" title="Réalisé avec TYPO3" /></a>
      </div>
    </div>
  </div>




</body>
</html>